const express=require("express")
const app=express();
app.use(express.json());
const port=3000;

//////////  BYCRYPT FOR PASSWORD   ////////////////////
const bcrypt = require('bcryptjs');
//////////  FETCH USER FUNCTION   ///////////////////
const fetchuser=require("./fechUser/fetchuser")
///////////  JSON WEB TOKEN ///////////////////
const secret_code="z4x5c6vt"

const jwt = require('jsonwebtoken');
////////////  BODY-PARSER  /////////////
const bodyParser=require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
/////////////////////////  DATABASE   ////////////////////////////////
require("./db/data")
////////////////////////   SCHEMA  /////////////////////////////////
const Uploads = require("./schema/schema");

const UploadDetails=require("./schema/uploadSchema")

//////////////////////////  PATH   ///////////////////////////////
const path = require('path');
app.set('views',path.join(__dirname,'views'));
app.set("view engine","ejs")
app.use(express.static("public")); 
/////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////
app.get("/",async(req,res)=>{
    try{
        const registrations=await Uploads.find({})
        res.json(registrations)
    }catch(err){
        res.send("error"+err)
    }
    // res.render("register")
    // res.send("get registration data")
})
///////////////////////////////////////////////////////////////////
app.get("/login",(req,res)=>{
    // if (req.body.email===Uploads.find({},{email:1})){
    //     console.log("get login data")
    //     res.send("hello")
    // }
    // res.send(req.body)
     res.render("login")
    // console.log("get login data")
})
///////////////////////////////////////////////////////////////////////
app.get("/register",(req,res)=>{
    // res.send("done")
     res.render("register")
})

///////////////////////////////////////////////////////////////////////
app.post("/register",async(req,res)=>{ 
    const salt=await bcrypt.genSalt(10);
    const hash=await bcrypt.hash(req.body.password,salt)

    //$2a$10$50nrNOkzC8XwNJ3fI9PIDuuskkd82jKSOE7Od5eLlATJjw9v6V44O"
    //"$2a$10$KQX7odvLIhLRp8fvxpczNOPTcb5iqBV1cCtpxWE9gLkf54NY7mLjq"
    try{   
    const uploads=  new Uploads({
        name:req.body.name,
        email:req.body.email,
        password:hash
    })
    
    const upload_temp=await uploads.save();
   
    res.send(
        {
            status:"success",
            data:upload_temp
        })
        // res.redirect("/login")
}catch(error){
    res.status(400).send(error);
}
// res.redirect("/");   
})
///////////////////////////////////////////////////////////////////////////////////////
app.post("/login",async(req,res)=>{    
   await Uploads.findOne({email:req.body.email})    
     .then((user)=> {          
            if (user === null) { 
                return res.status(400).send({ 
                    message : "User not found.",
                    status:user
                }); 
            } 
            else { 
                bcrypt.compare(req.body.password, user.password, (err, data) => {
                    //if error than throw error
                    if (err) throw err
    
                    //if both match than you can do anything
                    if (data) {
                        const payload={
                                    user :{
                                        id:user.id
                                    }
                                }
                                console.log(payload)
                                const authToken=jwt.sign(payload,secret_code)
                        return res.status(200).json({ msg: "Login success",authToken })
                    } else {
                        return res.status(401).json({ msg: "Invalid credencial" })
                    }
    
                })
                // if (bcrypt.compare(req.body.password,user.password)) { 
                //     console.log(req.body.password,"   ",user.password)
                //     const payload={
                //         user :{
                //             id:user.id
                //         }
                //     }
                //     const authToken=jwt.sign(payload,secret_code)
                //     return res.status(201).send(
                //         {message : "User Logged In" ,
                //         authToken,user
                //     })
                // } 
                // else {  
                //     return res.status(400).send({ 
                //         message : "Wrong Password"
                //     }); 
                // } 
            } 
        }); 
})
///////////////////////////////////////////////////////////////////////////////////////////

app.get("/posts",fetchuser,async(req,res)=>{
    const EachUpload=await UploadDetails.find({user:req.user.id})
    res.send(EachUpload)
})

//////////////////////////////////////////////////////////////////////////////////////////////////////
app.post("/getuser",fetchuser,async(req,res)=>{
    try{
        const userId=req.user.id;
        const user=await Uploads.findById(userId).select("-password")
        res.send(user)
    }
    catch(err){res.status(500).send(err)}
})

app.post("/posts",fetchuser, async(req,res)=>{
    try{   
        const uploads_pics=  new UploadDetails({
            title:req.body.title,
            body:req.body.body,
            image:req.body.image,
            user:req.user.id
                 
        })        
        const upload_pic_temp=await uploads_pics.save();
       
        res.send(
            {
                status:"post created",
                data:upload_pic_temp
            })
            // res.redirect("/login")
    }catch(error){
        res.status(400).send(error+"error");
    }

})
///////////////////////////////////////////////////////////////////////////////////////
app.put("/posts/:id",fetchuser,async(req,res)=>{
    const postId=req.params.id;
    const {title,body,image}=req.body;
  
    const newNote={}
    if (title){
        newNote.title=title}
    if(body){
        newNote.body=body
    }
    if(image){        
        newNote.image=image
        }
    
    ///find the note and update
    let note =await UploadDetails.findById(postId);
    
    if(!note){
        return res.status(401).send("post not found")
    }
    let correct_person= await Uploads.findOne({_id:note.user})

    if(!correct_person){
        return res.status(401).send("not matched || no post")
    }
    if (note.user.toString() != req.user.id){
        return res.status(401).send("not allowed make changes")
    }
    note = await UploadDetails.findByIdAndUpdate(postId,
        {$set:newNote},{new:true})
        console.log(newNote)
        res.send(note +"successfully updated")
})
/////////////////////////////////////////////////////////////////////////////////////////
app.delete("/posts/:id", fetchuser,async(req,res)=>{
    const postId=req.params.id;
    let note =await UploadDetails.findById(postId);
    if(!note){
        return res.status(401).send("post not found")
    }
    let correct_person= await Uploads.findOne({_id:note.user})

    if(!correct_person){
        return res.status(401).send("not matched || no post")
    }
    if (note.user.toString() != req.user.id){
        
        return res.status(401).send("not allowed make changes")
    }
    UploadDetails.findByIdAndDelete(postId).then(()=> res.send("deleted"))
   
})
/////////////////////////////////////////////////////////////////////////////////////////////
app.listen(port,()=>{console.log("server connected to ",port)})










// exports.login = (req, res) => {
//     let {email,password} = req.body;
//     User.findOne({email: email}).then(user => {
//        if (!user) {
//           return res.status(404).json({
//              errors: [{
//                 user: "not found"
//              }],
//           });
//        } else {
//           bcrypt.compare(password, user.password).then(isMatch => {
//              if (!isMatch) {
//                 return res.status(400).json({
//                    errors: [{
//                       password: "incorrect"
//                    }]
//                 });
//              }
//              let access_token = createJWT(
//                 user.email,
//                 user._id, 
//                 3600
//              );
//              jwt.verify(access_token, process.env.TOKEN_SECRET, (err,
//                 decoded) => {
//                 if (err) {
//                    res.status(500).json({
//                       errors: err
//                    });
//                 }
//                 if (decoded) {
//                    return res.status(200).json({
//                       success: true,
//                       token: access_token,
//                       message: user
//                    });
//                 }
//              });
//           }).catch(err => {
//              res.status(500).json({
//                 errors: err
//              });
//           });
//        }
//     }).catch(err => {
//        res.status(500).json({
//           errors: err
//        });
//     });
//  }





// app.post("/login",async(req,res)=>{
    
//     const mail= await Uploads.find({email:req.body.email,password:req.body.password})

//     if (mail===""){
//         res.send("user is not existed")
        
//     }
//  else if (req.body.email===mail[0].email  && req.body.password===mail[0].password){
//     res.send({status:"success"})
//  }
// else{
//     res.send(err+"logged in failed")
// }
 
  
// })