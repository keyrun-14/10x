
const mongoose=require("mongoose");
const { Schema } = mongoose;
const eachUpload= new mongoose.Schema({
    title:{
        type:String,
        required:true
    },
    body:{
        type:String,
        required:true
    },
    image:{
        type:String,
        required:true
    },
    user:{
        type: Schema.Types.ObjectId, 
        ref: "UploadedData"
    } 
    ,
    date:{
        type: Date, 
        default: Date.now
    }
})
const UploadDetails= new mongoose.model("mainData",eachUpload)
module.exports=UploadDetails